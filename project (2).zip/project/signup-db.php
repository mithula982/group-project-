<?php

$firstname = filter_input(INPUT_POST, 'firstname');
$lastname = filter_input(INPUT_POST, 'lastname');
$address = filter_input(INPUT_POST, 'address');
$email = filter_input(INPUT_POST, 'email');
$telno = filter_input(INPUT_POST, 'telno');
$password = filter_input(INPUT_POST, 'password');
$role = filter_input(INPUT_POST, 'role');

if (!empty($firstname)){
if (!empty($password)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "starfest";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
    $sql = "INSERT INTO form(firstname, lastname, address, email, telno, password,role)
VALUES ('$firstname','$lastname','$address','$email','$telno','$password','$role')";
    if($role=='eventorganizer'){
$sql = "INSERT INTO event_organizer(firstname, lastname, address, email, telno, password)
VALUES ('$firstname','$lastname','$address','$email','$telno','$password')";}
elseif($role=='eventparticipant'){
    $sql = "INSERT INTO event_participant(firstname, lastname, address, email, telno, password)
    VALUES ('$firstname','$lastname','$address','$email','$telno','$password')";}
    elseif($role=='serviceprovider'){
        $sql = "INSERT INTO service_provider(firstname, lastname, address, email, telno, password)
        VALUES ('$firstname','$lastname','$address','$email','$telno','$password')";}

if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Password should not be empty";
die();
}
}
else{
echo "Username should not be empty";
die();
}
?>